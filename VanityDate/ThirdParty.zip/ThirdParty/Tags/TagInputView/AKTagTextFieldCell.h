//
//  AKTagTextFieldCell.h
//
//  Created by Andrey Kadochnikov on 30.05.14.
//  Copyright (c) 2014 Andrey Kadochnikov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AKTextField.h"
@interface AKTagTextFieldCell : UICollectionViewCell
@property (nonatomic, strong) AKTextField *textField;
@end
