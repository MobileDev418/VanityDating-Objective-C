//
//  Constants.h
//  AKTagsInputViewExample
//
//  Created by Andrey K. on 22.02.15.
//  Copyright (c) 2015 Andrey Kadochnikov. All rights reserved.
//

#define ZWWS (@"\u200b") // this invisible symbol is placed at the very first textfield element. 