//
//  OTNotificationWindow.h
//  OTNotificationViewDemo
//
//  Created by openthread on 8/11/13.
//
//  A window won't excute renderInContext: method, to avoid be screen shoted.

#import <UIKit/UIKit.h>

@interface ComOpenthreadOTNotificationNoneRenderInContextWindow : UIWindow

@end
